package model.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.Usuario;
import util.Conexao;

public class UsuarioDAO {
	
	public static Usuario cadastrarUsuario(String login , String senha, int tipo, String descricao){
		
		Usuario usuario = null;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();
		
		String sql = "INSERT INTO usuario (login, senha, tipo, descricao) VALUES (?, ?, ?, ?)";
		
		try {

			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, login);
			stmt.setString(2, senha);
			stmt.setInt(3, tipo);
			stmt.setString(4, descricao);

			stmt.executeUpdate();

			con.close();
			stmt.close();

		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return usuario;
	}
	
	public static boolean excluirUsuario(String login, String senha){
		
		boolean ok = false;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();

		String sql = "DELETE FROM usuario WHERE login = ? and senha = ?";

		try {
			
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, login);
			stmt.setString(2, senha);
			
			ok = stmt.executeUpdate()>0;

			con.close();
			stmt.close();

		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return ok;
	}
	
	public static boolean atualizarUsuario(String login, String senha, int tipo, String descricao){
		
		boolean ok = false;
		Conexao conexao = new Conexao();
		Connection con = conexao.obterConexao();

		String sql = "UPDATE usuario SET login = ?, senha = ?, tipo = ?, descricao = ? WHERE idUsuario = ?";

		try {
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setString(1, login);
			stmt.setString(2, senha);
			stmt.setInt(3, tipo);
			stmt.setString(4, descricao);
	
			ok = stmt.executeUpdate()>0;

			con.close();
			stmt.close();
			
		} catch (SQLException e) {
			System.out.println("Erro ao acessar o banco de dados.");
			System.out.println("Verifique sua instru��o SQL");
			System.out.println("Mensagem: "+e.getMessage());
		}
		
		return ok;
	}	
	
}