package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JTabbedPane;
import java.awt.GridBagConstraints;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;

import java.awt.Insets;
import javax.swing.ImageIcon;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Date;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.border.MatteBorder;
import javax.swing.border.SoftBevelBorder;

import util.ManipularImagem;

import javax.swing.JTextPane;
import com.toedter.calendar.JDateChooser;

import model.Categoria;
import model.Endereco;
import model.Produto;
import model.DAO.CategoriaDAO;
import model.DAO.ClienteDAO;
import model.DAO.EnderecoDAO;
import model.DAO.ProdutoDAO;

public class CadastroProduto extends JFrame {

	private JPanel contentPane;
	private JTextField txtDescricao;
	private JTextField txtCodigoBarra;
	private JTextField txtValorCusto;
	private JTextField txtValorVenda;
	private JTextField txtMarca;
	private JTextField txtFornecedor;
	private JTextField txtQuantidade;
	private JTextField txtLote;

	
	private BufferedImage imagem;
	private JTextField txtNome;
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroProduto cadCliente = new CadastroProduto();
					cadCliente.setVisible(true);
					cadCliente.setResizable(false);
					cadCliente.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CadastroProduto() {
		setTitle("Cadastro de Produto");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 649, 434);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{1.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		GridBagConstraints gbc_tabbedPane = new GridBagConstraints();
		gbc_tabbedPane.insets = new Insets(0, 0, 5, 0);
		gbc_tabbedPane.fill = GridBagConstraints.BOTH;
		gbc_tabbedPane.gridx = 0;
		gbc_tabbedPane.gridy = 0;
		contentPane.add(tabbedPane, gbc_tabbedPane);
		
		JLayeredPane layeredPaneInformacpesBasicasDeProduto = new JLayeredPane();
		tabbedPane.addTab("Informa\u00E7\u00F5es b\u00E1sicas do Produto", new ImageIcon(CadastroProduto.class.getResource("/imagens/produto24.png")), layeredPaneInformacpesBasicasDeProduto, null);
		GridBagLayout gbl_layeredPaneInformacpesBasicasDeProduto = new GridBagLayout();
		gbl_layeredPaneInformacpesBasicasDeProduto.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gbl_layeredPaneInformacpesBasicasDeProduto.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_layeredPaneInformacpesBasicasDeProduto.columnWeights = new double[]{1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_layeredPaneInformacpesBasicasDeProduto.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		layeredPaneInformacpesBasicasDeProduto.setLayout(gbl_layeredPaneInformacpesBasicasDeProduto);
		
		JLabel lblNome = new JLabel("Nome");
		GridBagConstraints gbc_lblNome = new GridBagConstraints();
		gbc_lblNome.anchor = GridBagConstraints.WEST;
		gbc_lblNome.insets = new Insets(0, 0, 5, 5);
		gbc_lblNome.gridx = 0;
		gbc_lblNome.gridy = 0;
		layeredPaneInformacpesBasicasDeProduto.add(lblNome, gbc_lblNome);
		
		JLabel lblNewLabel = new JLabel("Descri��o do Produto");
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.gridwidth = 2;
		gbc_lblNewLabel.anchor = GridBagConstraints.WEST;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 2;
		gbc_lblNewLabel.gridy = 0;
		layeredPaneInformacpesBasicasDeProduto.add(lblNewLabel, gbc_lblNewLabel);
		
		txtNome = new JTextField();
		GridBagConstraints gbc_txtNome = new GridBagConstraints();
		gbc_txtNome.gridwidth = 2;
		gbc_txtNome.insets = new Insets(0, 0, 5, 5);
		gbc_txtNome.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtNome.gridx = 0;
		gbc_txtNome.gridy = 1;
		layeredPaneInformacpesBasicasDeProduto.add(txtNome, gbc_txtNome);
		txtNome.setColumns(10);
		
		txtDescricao = new JTextField();
		GridBagConstraints gbc_txtDescricao = new GridBagConstraints();
		gbc_txtDescricao.gridwidth = 5;
		gbc_txtDescricao.insets = new Insets(0, 0, 5, 0);
		gbc_txtDescricao.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtDescricao.gridx = 2;
		gbc_txtDescricao.gridy = 1;
		layeredPaneInformacpesBasicasDeProduto.add(txtDescricao, gbc_txtDescricao);
		txtDescricao.setColumns(10);
		
		JLabel lblCodigoBarra = new JLabel("C\u00F3digo De Barra");
		GridBagConstraints gbc_lblCodigoBarra = new GridBagConstraints();
		gbc_lblCodigoBarra.insets = new Insets(0, 0, 5, 5);
		gbc_lblCodigoBarra.anchor = GridBagConstraints.WEST;
		gbc_lblCodigoBarra.gridx = 0;
		gbc_lblCodigoBarra.gridy = 2;
		layeredPaneInformacpesBasicasDeProduto.add(lblCodigoBarra, gbc_lblCodigoBarra);
		
		JLabel lblValorCusto = new JLabel("Valor custo");
		GridBagConstraints gbc_lblValorCusto = new GridBagConstraints();
		gbc_lblValorCusto.anchor = GridBagConstraints.WEST;
		gbc_lblValorCusto.insets = new Insets(0, 0, 5, 5);
		gbc_lblValorCusto.gridx = 1;
		gbc_lblValorCusto.gridy = 2;
		layeredPaneInformacpesBasicasDeProduto.add(lblValorCusto, gbc_lblValorCusto);
		
		JLabel lblValorVenda = new JLabel("Valor venda");
		GridBagConstraints gbc_lblValorVenda = new GridBagConstraints();
		gbc_lblValorVenda.anchor = GridBagConstraints.WEST;
		gbc_lblValorVenda.insets = new Insets(0, 0, 5, 5);
		gbc_lblValorVenda.gridx = 2;
		gbc_lblValorVenda.gridy = 2;
		layeredPaneInformacpesBasicasDeProduto.add(lblValorVenda, gbc_lblValorVenda);
		
		JLabel lblDataDeFabricao = new JLabel("Data de Fabrica��o Dia/M�s/Ano");
		GridBagConstraints gbc_lblDataDeFabricao = new GridBagConstraints();
		gbc_lblDataDeFabricao.anchor = GridBagConstraints.WEST;
		gbc_lblDataDeFabricao.gridwidth = 2;
		gbc_lblDataDeFabricao.insets = new Insets(0, 0, 5, 5);
		gbc_lblDataDeFabricao.gridx = 3;
		gbc_lblDataDeFabricao.gridy = 2;
		layeredPaneInformacpesBasicasDeProduto.add(lblDataDeFabricao, gbc_lblDataDeFabricao);
		
		JLabel lblCategoria = new JLabel("Categoria");
		GridBagConstraints gbc_lblCategoria = new GridBagConstraints();
		gbc_lblCategoria.anchor = GridBagConstraints.WEST;
		gbc_lblCategoria.insets = new Insets(0, 0, 5, 5);
		gbc_lblCategoria.gridx = 5;
		gbc_lblCategoria.gridy = 2;
		layeredPaneInformacpesBasicasDeProduto.add(lblCategoria, gbc_lblCategoria);
		
		txtCodigoBarra = new JTextField();
		GridBagConstraints gbc_txtCodigoBarra = new GridBagConstraints();
		gbc_txtCodigoBarra.insets = new Insets(0, 0, 5, 5);
		gbc_txtCodigoBarra.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtCodigoBarra.gridx = 0;
		gbc_txtCodigoBarra.gridy = 3;
		layeredPaneInformacpesBasicasDeProduto.add(txtCodigoBarra, gbc_txtCodigoBarra);
		txtCodigoBarra.setColumns(10);
		
		txtValorCusto = new JTextField();
		GridBagConstraints gbc_txtValorCusto = new GridBagConstraints();
		gbc_txtValorCusto.insets = new Insets(0, 0, 5, 5);
		gbc_txtValorCusto.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtValorCusto.gridx = 1;
		gbc_txtValorCusto.gridy = 3;
		layeredPaneInformacpesBasicasDeProduto.add(txtValorCusto, gbc_txtValorCusto);
		txtValorCusto.setColumns(10);
		
		txtValorVenda = new JTextField();
		GridBagConstraints gbc_txtValorVenda = new GridBagConstraints();
		gbc_txtValorVenda.insets = new Insets(0, 0, 5, 5);
		gbc_txtValorVenda.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtValorVenda.gridx = 2;
		gbc_txtValorVenda.gridy = 3;
		layeredPaneInformacpesBasicasDeProduto.add(txtValorVenda, gbc_txtValorVenda);
		txtValorVenda.setColumns(10);
		
		
		String[] vetorDia = {"1", "2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17",
				"18","19","20","21","22","23","24","25","26","27","28","29","30","31",};
		
		
		String[] vetorMes = {"1", "2","3","4","5","6","7","8","9","10","11","12"};
		
		JDateChooser dateChooserFabricacao = new JDateChooser();
		GridBagConstraints gbc_dateChooserFabricacao = new GridBagConstraints();
		gbc_dateChooserFabricacao.insets = new Insets(0, 0, 5, 5);
		gbc_dateChooserFabricacao.fill = GridBagConstraints.HORIZONTAL;
		gbc_dateChooserFabricacao.gridx = 3;
		gbc_dateChooserFabricacao.gridy = 3;
		layeredPaneInformacpesBasicasDeProduto.add(dateChooserFabricacao, gbc_dateChooserFabricacao);
		
		String[] categorias = {"A", "B", "C"};
		
		JComboBox comboBoxCategoria = new JComboBox(categorias);
		comboBoxCategoria.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				
				
				
			}
		});
		//comboBox.addActionListener(event -> {
			//JComboBox cb = (JComboBox) event.getSource();
		//	String conteudo = (String) cb.getSelectedItem();
			//if(cb.getSelectedItem() == null) {
				
		//	}
		//});
		
		GridBagConstraints gbc_comboBoxCategoria = new GridBagConstraints();
		gbc_comboBoxCategoria.insets = new Insets(0, 0, 5, 5);
		gbc_comboBoxCategoria.fill = GridBagConstraints.HORIZONTAL;
		gbc_comboBoxCategoria.gridx = 5;
		gbc_comboBoxCategoria.gridy = 3;
		layeredPaneInformacpesBasicasDeProduto.add(comboBoxCategoria, gbc_comboBoxCategoria);
		
		JButton btnNew = new JButton("Nova");
		btnNew.setToolTipText("Nova Categoria");
		btnNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				CadastroCategoria cadCategoria = new CadastroCategoria();
				cadCategoria.setVisible(true);
				cadCategoria.setResizable(false);
				cadCategoria.setLocationRelativeTo(null);
			}
		});
		GridBagConstraints gbc_btnNew = new GridBagConstraints();
		gbc_btnNew.insets = new Insets(0, 0, 5, 0);
		gbc_btnNew.gridx = 6;
		gbc_btnNew.gridy = 3;
		layeredPaneInformacpesBasicasDeProduto.add(btnNew, gbc_btnNew);
		
		JLabel lblMarca = new JLabel("Marca");
		GridBagConstraints gbc_lblMarca = new GridBagConstraints();
		gbc_lblMarca.anchor = GridBagConstraints.WEST;
		gbc_lblMarca.insets = new Insets(0, 0, 5, 5);
		gbc_lblMarca.gridx = 0;
		gbc_lblMarca.gridy = 4;
		layeredPaneInformacpesBasicasDeProduto.add(lblMarca, gbc_lblMarca);
		
		JLabel lblFornecedor = new JLabel("Fornecedor");
		GridBagConstraints gbc_lblFornecedor = new GridBagConstraints();
		gbc_lblFornecedor.anchor = GridBagConstraints.WEST;
		gbc_lblFornecedor.insets = new Insets(0, 0, 5, 5);
		gbc_lblFornecedor.gridx = 1;
		gbc_lblFornecedor.gridy = 4;
		layeredPaneInformacpesBasicasDeProduto.add(lblFornecedor, gbc_lblFornecedor);
		
		JLabel lblQuantidade = new JLabel("Quantidade");
		GridBagConstraints gbc_lblQuantidade = new GridBagConstraints();
		gbc_lblQuantidade.anchor = GridBagConstraints.WEST;
		gbc_lblQuantidade.insets = new Insets(0, 0, 5, 5);
		gbc_lblQuantidade.gridx = 2;
		gbc_lblQuantidade.gridy = 4;
		layeredPaneInformacpesBasicasDeProduto.add(lblQuantidade, gbc_lblQuantidade);
		
		JLabel lblLote = new JLabel("Lote");
		GridBagConstraints gbc_lblLote = new GridBagConstraints();
		gbc_lblLote.gridwidth = 2;
		gbc_lblLote.anchor = GridBagConstraints.WEST;
		gbc_lblLote.insets = new Insets(0, 0, 5, 5);
		gbc_lblLote.gridx = 3;
		gbc_lblLote.gridy = 4;
		layeredPaneInformacpesBasicasDeProduto.add(lblLote, gbc_lblLote);
		
		JLabel lblVencimento = new JLabel("Vencimento");
		GridBagConstraints gbc_lblVencimento = new GridBagConstraints();
		gbc_lblVencimento.anchor = GridBagConstraints.NORTHWEST;
		gbc_lblVencimento.insets = new Insets(0, 0, 5, 5);
		gbc_lblVencimento.gridx = 5;
		gbc_lblVencimento.gridy = 4;
		layeredPaneInformacpesBasicasDeProduto.add(lblVencimento, gbc_lblVencimento);
		
		txtMarca = new JTextField();
		GridBagConstraints gbc_txtMarca = new GridBagConstraints();
		gbc_txtMarca.insets = new Insets(0, 0, 5, 5);
		gbc_txtMarca.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtMarca.gridx = 0;
		gbc_txtMarca.gridy = 5;
		layeredPaneInformacpesBasicasDeProduto.add(txtMarca, gbc_txtMarca);
		txtMarca.setColumns(10);
		
		txtFornecedor = new JTextField();
		GridBagConstraints gbc_txtFornecedor = new GridBagConstraints();
		gbc_txtFornecedor.insets = new Insets(0, 0, 5, 5);
		gbc_txtFornecedor.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtFornecedor.gridx = 1;
		gbc_txtFornecedor.gridy = 5;
		layeredPaneInformacpesBasicasDeProduto.add(txtFornecedor, gbc_txtFornecedor);
		txtFornecedor.setColumns(10);
		
		txtQuantidade = new JTextField();
		GridBagConstraints gbc_txtQuantidade = new GridBagConstraints();
		gbc_txtQuantidade.insets = new Insets(0, 0, 5, 5);
		gbc_txtQuantidade.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtQuantidade.gridx = 2;
		gbc_txtQuantidade.gridy = 5;
		layeredPaneInformacpesBasicasDeProduto.add(txtQuantidade, gbc_txtQuantidade);
		txtQuantidade.setColumns(10);
		
		txtLote = new JTextField();
		GridBagConstraints gbc_txtLote = new GridBagConstraints();
		gbc_txtLote.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtLote.gridwidth = 2;
		gbc_txtLote.insets = new Insets(0, 0, 5, 5);
		gbc_txtLote.gridx = 3;
		gbc_txtLote.gridy = 5;
		layeredPaneInformacpesBasicasDeProduto.add(txtLote, gbc_txtLote);
		txtLote.setColumns(10);
		
		JDateChooser dateChooserVencimento = new JDateChooser();
		GridBagConstraints gbc_dateChooserVencimento = new GridBagConstraints();
		gbc_dateChooserVencimento.gridwidth = 2;
		gbc_dateChooserVencimento.insets = new Insets(0, 0, 5, 5);
		gbc_dateChooserVencimento.fill = GridBagConstraints.BOTH;
		gbc_dateChooserVencimento.gridx = 5;
		gbc_dateChooserVencimento.gridy = 5;
		layeredPaneInformacpesBasicasDeProduto.add(dateChooserVencimento, gbc_dateChooserVencimento);
		
		JLabel lblInformaes = new JLabel("Informa��es adicinionais:");
		GridBagConstraints gbc_lblInformaes = new GridBagConstraints();
		gbc_lblInformaes.anchor = GridBagConstraints.WEST;
		gbc_lblInformaes.gridwidth = 2;
		gbc_lblInformaes.insets = new Insets(0, 0, 5, 5);
		gbc_lblInformaes.gridx = 0;
		gbc_lblInformaes.gridy = 6;
		layeredPaneInformacpesBasicasDeProduto.add(lblInformaes, gbc_lblInformaes);
		
		JTextArea textAreaIformacoesAdicionais = new JTextArea();
		GridBagConstraints gbc_textArea = new GridBagConstraints();
		gbc_textArea.gridwidth = 7;
		gbc_textArea.fill = GridBagConstraints.BOTH;
		gbc_textArea.gridx = 0;
		gbc_textArea.gridy = 7;
		
		//pular de linha quando n�o couber mais na linha
		textAreaIformacoesAdicionais.setLineWrap(true);
						 //descer com a palavra quando ela n�o couber mais na linha
		textAreaIformacoesAdicionais.setWrapStyleWord(true);
						JScrollPane sp = new JScrollPane(textAreaIformacoesAdicionais, 
								 JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, 
								 JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		layeredPaneInformacpesBasicasDeProduto.add(sp, gbc_textArea);
		
		JLayeredPane layeredPaneObservcoesEFoto = new JLayeredPane();
		tabbedPane.addTab("Observa��es e foto", null, layeredPaneObservcoesEFoto, null);
		GridBagLayout gbl_layeredPaneObservcoesEFoto = new GridBagLayout();
		gbl_layeredPaneObservcoesEFoto.columnWidths = new int[]{0, 0};
		gbl_layeredPaneObservcoesEFoto.rowHeights = new int[]{0, 0};
		gbl_layeredPaneObservcoesEFoto.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_layeredPaneObservcoesEFoto.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		layeredPaneObservcoesEFoto.setLayout(gbl_layeredPaneObservcoesEFoto);
		
		JPanel panel_1 = new JPanel();
		GridBagConstraints gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.fill = GridBagConstraints.BOTH;
		gbc_panel_1.gridx = 0;
		gbc_panel_1.gridy = 0;
		layeredPaneObservcoesEFoto.add(panel_1, gbc_panel_1);
		GridBagLayout gbl_panel_1 = new GridBagLayout();
		gbl_panel_1.columnWidths = new int[]{0, 0, 0};
		gbl_panel_1.rowHeights = new int[]{0, 0, 0, 0};
		gbl_panel_1.columnWeights = new double[]{1.0, 0.0, Double.MIN_VALUE};
		gbl_panel_1.rowWeights = new double[]{0.0, 1.0, 0.0, Double.MIN_VALUE};
		panel_1.setLayout(gbl_panel_1);
		
		JLabel lblNew = new JLabel("FOTO DO PRODUTO:");
		GridBagConstraints gbc_lblNew = new GridBagConstraints();
		gbc_lblNew.gridwidth = 2;
		gbc_lblNew.insets = new Insets(0, 0, 5, 0);
		gbc_lblNew.gridx = 0;
		gbc_lblNew.gridy = 0;
		panel_1.add(lblNew, gbc_lblNew);
		
		JLabel lblImagem = new JLabel("");
		lblImagem.setToolTipText("Adicione uma imagem");
		lblImagem.setBackground(Color.WHITE);
		GridBagConstraints gbc_lblImagem = new GridBagConstraints();
		gbc_lblImagem.gridwidth = 2;
		gbc_lblImagem.insets = new Insets(0, 0, 5, 5);
		gbc_lblImagem.gridx = 0;
		gbc_lblImagem.gridy = 1;
		panel_1.add(lblImagem, gbc_lblImagem);
		
		JButton btnNewButton = new JButton("Adicinar Imagem");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				  JFileChooser fc = new JFileChooser();
			        int res = fc.showOpenDialog(null);
			        
			        if (res == JFileChooser.APPROVE_OPTION) {
			            File arquivo = fc.getSelectedFile();
			            
			            try {
			                imagem = ManipularImagem.setImagemDimensao(arquivo.getAbsolutePath(), 460, 260);
			                
			                lblImagem.setIcon(new ImageIcon(imagem));

			            } catch (Exception ex) {
			               // System.out.println(ex.printStackTrace().toString());
			            }

			        } else {
			            JOptionPane.showMessageDialog(null, "Voce nao selecionou nenhum arquivo.");
			        }	
			        
			        			
			}
		});
		btnNewButton.setIcon(new ImageIcon(CadastroProduto.class.getResource("/imagens/addImagem24.png")));
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.anchor = GridBagConstraints.WEST;
		gbc_btnNewButton.insets = new Insets(0, 0, 0, 5);
		gbc_btnNewButton.gridx = 0;
		gbc_btnNewButton.gridy = 2;
		panel_1.add(btnNewButton, gbc_btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Limpar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//lblImagem.setText(""); 
				
			}
		});
		btnNewButton_1.setIcon(new ImageIcon(CadastroProduto.class.getResource("/imagens/limpar24.png")));
		GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
		gbc_btnNewButton_1.anchor = GridBagConstraints.EAST;
		gbc_btnNewButton_1.gridx = 1;
		gbc_btnNewButton_1.gridy = 2;
		panel_1.add(btnNewButton_1, gbc_btnNewButton_1);
		
		
		JPanel panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel.anchor = GridBagConstraints.SOUTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 1;
		contentPane.add(panel, gbc_panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gbl_panel.rowHeights = new int[]{0, 0, 0, 0, 0};
		gbl_panel.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		JButton btnSalvar = new JButton("Salvar (F2)");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				/*Produto produto = new Produto();
				produto.setImagem(ManipularImagem.getImgBytes(imagem));*/
				
				if(txtCodigoBarra.getText().equals(null)
						&& txtNome.getText().equals(null)
						&& txtDescricao.getText().equals(null) 
						&& txtValorCusto.getText().equals(null) 
						&& txtValorVenda.getText().equals(null)
						//&& comboBoxCategoria.getText().equals(null
						&& txtMarca.getText().equals(null)
						&& txtFornecedor.getText().equals(null)
						&& txtQuantidade.getText().equals(null)
						&& txtLote.getText().equals(null) 
						//&& dateChooserFabricacao.getDate().equals(null) 
						//&& dateChooserVencimento.getDate().equals(null) 
						&& lblImagem.getText().equals(null)
						&& textAreaIformacoesAdicionais.getText().equals(null)){
					JOptionPane.showMessageDialog(null, "Preencha todos os campos");
				} else {
					
					
					/*ProdutoDAO.cadastrarProduto(Integer.parseInt(txtCodigoBarra.getText()), txtNome.getText(), Double.parseDouble(txtValorCusto.getText()), 
							Double.parseDouble(txtValorVenda.getText()), txtDescricao.getText(), dateChooserFabricacao.getDate(), txtMarca.getText(), txtFornecedor.getText(),
							Integer.parseInt(txtQuantidade.getText()), txtLote.getText(), dateChooserVencimento.getDate(), lblImagem.getText(),
							comboBoxCategoria.getSelectedItem().toString(), textAreaIformacoesAdicionais.getText());*/
				}
				
			}
		});
		btnSalvar.setIcon(new ImageIcon(CadastroProduto.class.getResource("/imagens/iconSalvar.png")));
		GridBagConstraints gbc_btnSalvar = new GridBagConstraints();
		gbc_btnSalvar.anchor = GridBagConstraints.SOUTHEAST;
		gbc_btnSalvar.insets = new Insets(0, 0, 5, 5);
		gbc_btnSalvar.gridx = 0;
		gbc_btnSalvar.gridy = 0;
		panel.add(btnSalvar, gbc_btnSalvar);
		
		JButton btnFechar = new JButton("Fechar (ESC)");
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int resposta = JOptionPane.showConfirmDialog(null,
						"Tem certeza de que quer fechar a janela e perder todo o Conte�do?", 
						"Janela de confirma��o", JOptionPane.YES_NO_OPTION);
				
				switch(resposta){
				case JOptionPane.YES_OPTION:
					dispose();

					break;
				case JOptionPane.NO_OPTION:
					
				}
				
			}
		});
		btnFechar.setIcon(new ImageIcon(CadastroProduto.class.getResource("/imagens/fechar32.png")));
		GridBagConstraints gbc_btnFechar = new GridBagConstraints();
		gbc_btnFechar.anchor = GridBagConstraints.SOUTHEAST;
		gbc_btnFechar.insets = new Insets(0, 0, 5, 0);
		gbc_btnFechar.gridx = 6;
		gbc_btnFechar.gridy = 0;
		panel.add(btnFechar, gbc_btnFechar);
	}
}
