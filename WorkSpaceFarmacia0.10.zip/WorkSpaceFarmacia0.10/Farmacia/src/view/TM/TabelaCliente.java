package view.TM;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import model.Cliente;

public class TabelaCliente extends AbstractTableModel {
	
	private final List<Cliente> clientes;
	
	public TabelaCliente(List<Cliente> clientes) {
		this.clientes = clientes;
	}
	
	//busca o valor da coluna
	@Override
	public int getColumnCount() {
		return 9;
	}

	//busca o valor da linha
	@Override
	public int getRowCount() {
		return this.clientes.size();
	}

	//pegar os valores da coluna e de linha
	@Override
	public Object getValueAt(int linha, int coluna) {
		
		Cliente c = clientes.get(linha);
		
		switch (coluna) {
		case 0:
			return c.getNome();
		case 1:
			return c.getTelefone();
		case 2:
			return c.getEmail();
		case 3:
			return c.getSexo();
		case 4:
			return c.getCpf();
		case 5:
			return c.getRg();
		case 6:
			return c.getSituacao();
		case 7:
			return c.getNascimento();
		case 8:
			return c.getSituacao();
		default:
			return null;
			
		}
	}
	
	@Override
	public String getColumnName(int coluna){
		
		switch(coluna){
		case 0:
			return "Nome";
		case 1:
			return "Telefone";
		case 2:
			return "E-mail";
		case 3:
			return "Sexo";
		case 4:
			return "CPF";
		case 5:
			return "RG";
		case 6:
			return "Situa��o";
		case 7:
			return "Nascimento";
		case 8:
			return "Situa��o";
		
		default :
			return null;
			
		}
		
	}

}