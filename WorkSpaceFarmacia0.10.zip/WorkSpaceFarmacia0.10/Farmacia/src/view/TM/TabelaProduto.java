package view.TM;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import model.Produto;

public class TabelaProduto extends AbstractTableModel {
	
	private final List<Produto> produtos;
	
	public TabelaProduto(List<Produto> produtos) {
		this.produtos = produtos;
	}
	
	//busca o valor da coluna
	@Override
	public int getColumnCount() {
		return 11;
	}

	//busca o valor da linha
	@Override
	public int getRowCount() {
		
		return this.produtos.size();
	}

	//pegar os valores da coluna e de linha
	@Override
	public Object getValueAt(int linha, int coluna) {
		
		Produto p = produtos.get(linha);
		
		switch (coluna) {
		case 0:
			return p.getCodigo();
		case 1:
			return p.getNome();
		case 2:
			return p.getValorCusto();
		case 3:
			return p.getValorVenda();
		case 4:
			return p.getDescricao();
		case 5:
			return p.getDataFabricacao();
		case 6:
			return p.getMarca();
		case 7:
			return p.getFornecedor();
		case 8:
			return p.getQuantidade();
		case 9:
			return p.getVencimento();
		case 10:
			return p.getImagem();

		default:
			return null;
			
		}
	}
	
	@Override
	public String getColumnName(int coluna){
		
		switch(coluna){
		case 0:
			return "C�digo";
		case 1:
			return "Nome";
		case 2:
			return "Valor Custo";
		case 3:
			return "Valor Venda";
		case 4:
			return "Descri��o";
		case 5:
			return "Data Fabrica��o";
		case 6:
			return "Marca";
		case 7:
			return "Fornecedor";
		case 8:
			return "Quantidade";
		case 9:
			return "Vencimento";
		case 10:
			return "Imagem";
		default :
			return null;
			
		}
		
	}

}