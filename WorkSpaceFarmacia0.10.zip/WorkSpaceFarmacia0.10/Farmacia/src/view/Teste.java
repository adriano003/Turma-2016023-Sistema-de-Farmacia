package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.BevelBorder;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JRadioButton;

public class Teste extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Teste frame = new Teste();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Teste() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 653, 413);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel label = new JLabel("Procurar Por: ");
		label.setBounds(4, 36, 84, 14);
		panel.add(label);
		
		textField = new JTextField();
		textField.setBounds(93, 32, 305, 23);
		textField.setColumns(10);
		panel.add(textField);
		
		JButton button = new JButton("Pesquisar");
		button.setBounds(403, 32, 82, 23);
		panel.add(button);
		
		JButton button_1 = new JButton("Cadastrar");
		button_1.setBounds(4, 60, 84, 23);
		panel.add(button_1);
		
		JButton button_2 = new JButton("Alterar");
		button_2.setBounds(93, 60, 68, 23);
		panel.add(button_2);
		
		JButton button_3 = new JButton("Excluir");
		button_3.setBounds(166, 60, 66, 23);
		panel.add(button_3);
		
		JButton button_4 = new JButton("Consultar");
		button_4.setBounds(237, 60, 82, 23);
		panel.add(button_4);
		
		JButton button_5 = new JButton("Imprimir");
		button_5.setBounds(324, 60, 74, 23);
		panel.add(button_5);
		
		JButton button_6 = new JButton("Cancelar");
		button_6.setBounds(403, 60, 82, 23);
		panel.add(button_6);
		
		JLabel label_1 = new JLabel("Modos de Busca:");
		label_1.setBounds(4, 121, 113, 14);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel("Digite o Nome e precione Enter para localizar:");
		label_2.setBounds(4, 146, 256, 14);
		panel.add(label_2);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(4, 165, 342, 20);
		panel.add(textField_1);
		
		JLabel label_3 = new JLabel("C\u00F3digo:");
		label_3.setBounds(356, 146, 46, 14);
		panel.add(label_3);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(356, 165, 134, 20);
		panel.add(textField_2);
		
		JLabel label_4 = new JLabel("Fornecedor:");
		label_4.setBounds(500, 146, 83, 14);
		panel.add(label_4);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(500, 165, 120, 20);
		panel.add(textField_3);
		
		JRadioButton radioButton = new JRadioButton("Fornecedor");
		radioButton.setBounds(195, 226, 81, 23);
		panel.add(radioButton);
		
		JRadioButton radioButton_1 = new JRadioButton("Nome  ");
		radioButton_1.setSelected(true);
		radioButton_1.setBounds(125, 226, 59, 23);
		panel.add(radioButton_1);
		
		JRadioButton radioButton_2 = new JRadioButton("C\u00F3digo");
		radioButton_2.setBounds(125, 259, 59, 23);
		panel.add(radioButton_2);
		
		JLabel label_5 = new JLabel("Modos de pesquisas dispon\u00EDveis: ");
		label_5.setBounds(136, 196, 158, 14);
		panel.add(label_5);
	}
}
