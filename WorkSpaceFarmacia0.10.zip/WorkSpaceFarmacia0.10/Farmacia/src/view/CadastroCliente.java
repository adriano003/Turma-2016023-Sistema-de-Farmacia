package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JTabbedPane;
import java.awt.GridBagConstraints;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;

import java.awt.Insets;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;

import model.Endereco;
import model.DAO.ClienteDAO;
import model.DAO.EnderecoDAO;
import com.toedter.calendar.JDateChooser;

public class CadastroCliente extends JFrame {
	
	private JPanel contentPane;
	private JTextField txtCodigo;
	private JTextField txtNomeDoCliente;
	private JTextField txtCpf;
	private JTextField txtTelefone;
	private JTextField txtRg;
	private JTextField txtCidade;
	private JTextField txtUF;
	private JTextField txtEmail;
	private JTextField txtLogradouro;
	private JTextField txtNumero;
	private JTextField txtComplemento;
	private JTextField txtBairro;
	private JTextField txtCep;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroCliente cadCliente = new CadastroCliente();
					cadCliente.setVisible(true);
					cadCliente.setResizable(false);
					cadCliente.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	/**
	 * Create the frame.
	 */
	public CadastroCliente() {
		setTitle("Cadastro de Cliente");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 638, 508);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{1.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		GridBagConstraints gbc_tabbedPane = new GridBagConstraints();
		gbc_tabbedPane.insets = new Insets(0, 0, 5, 0);
		gbc_tabbedPane.fill = GridBagConstraints.BOTH;
		gbc_tabbedPane.gridx = 0;
		gbc_tabbedPane.gridy = 0;
		contentPane.add(tabbedPane, gbc_tabbedPane);
		
		JLayeredPane layeredPane = new JLayeredPane();
		layeredPane.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		tabbedPane.addTab("Informa��es B�sicas de Cliente", new ImageIcon(CadastroCliente.class.getResource("/imagens/iconCliente24.png")), layeredPane, null);
		GridBagLayout gbl_layeredPane = new GridBagLayout();
		gbl_layeredPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0};
		gbl_layeredPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_layeredPane.columnWeights = new double[]{0.0, 1.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
		gbl_layeredPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		layeredPane.setLayout(gbl_layeredPane);
		
		JLabel lblCdigoaltomtico = new JLabel("C\u00F3digo (Autom\u00E1tico)");
		GridBagConstraints gbc_lblCdigoaltomtico = new GridBagConstraints();
		gbc_lblCdigoaltomtico.insets = new Insets(0, 0, 5, 5);
		gbc_lblCdigoaltomtico.gridx = 0;
		gbc_lblCdigoaltomtico.gridy = 0;
		layeredPane.add(lblCdigoaltomtico, gbc_lblCdigoaltomtico);
		
		JLabel lblNomeDoCliente = new JLabel("Nome do Cliente");
		GridBagConstraints gbc_lblNomeDoCliente = new GridBagConstraints();
		gbc_lblNomeDoCliente.anchor = GridBagConstraints.WEST;
		gbc_lblNomeDoCliente.insets = new Insets(0, 0, 5, 5);
		gbc_lblNomeDoCliente.gridx = 1;
		gbc_lblNomeDoCliente.gridy = 0;
		layeredPane.add(lblNomeDoCliente, gbc_lblNomeDoCliente);
		
		txtCodigo = new JTextField();
		GridBagConstraints gbc_txtCodigo = new GridBagConstraints();
		gbc_txtCodigo.insets = new Insets(0, 0, 5, 5);
		gbc_txtCodigo.anchor = GridBagConstraints.NORTH;
		gbc_txtCodigo.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtCodigo.gridx = 0;
		gbc_txtCodigo.gridy = 1;
		layeredPane.add(txtCodigo, gbc_txtCodigo);
		txtCodigo.setEditable(false);
		txtCodigo.setColumns(10);
		
		txtNomeDoCliente = new JTextField();
		GridBagConstraints gbc_txtNomeDoCliente = new GridBagConstraints();
		gbc_txtNomeDoCliente.gridwidth = 4;
		gbc_txtNomeDoCliente.insets = new Insets(0, 0, 5, 0);
		gbc_txtNomeDoCliente.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtNomeDoCliente.gridx = 1;
		gbc_txtNomeDoCliente.gridy = 1;
		layeredPane.add(txtNomeDoCliente, gbc_txtNomeDoCliente);
		txtNomeDoCliente.setColumns(10);
		
		JLabel lblCpf = new JLabel("CPF");
		GridBagConstraints gbc_lblCpf = new GridBagConstraints();
		gbc_lblCpf.anchor = GridBagConstraints.WEST;
		gbc_lblCpf.insets = new Insets(0, 0, 5, 5);
		gbc_lblCpf.gridx = 0;
		gbc_lblCpf.gridy = 2;
		layeredPane.add(lblCpf, gbc_lblCpf);
		
		JLabel lblRg = new JLabel("RG");
		GridBagConstraints gbc_lblRg = new GridBagConstraints();
		gbc_lblRg.anchor = GridBagConstraints.WEST;
		gbc_lblRg.insets = new Insets(0, 0, 5, 5);
		gbc_lblRg.gridx = 1;
		gbc_lblRg.gridy = 2;
		layeredPane.add(lblRg, gbc_lblRg);
		
		JLabel lblSexo = new JLabel("Sexo");
		GridBagConstraints gbc_lblSexo = new GridBagConstraints();
		gbc_lblSexo.anchor = GridBagConstraints.WEST;
		gbc_lblSexo.insets = new Insets(0, 0, 5, 5);
		gbc_lblSexo.gridx = 2;
		gbc_lblSexo.gridy = 2;
		layeredPane.add(lblSexo, gbc_lblSexo);
		
		JLabel lblTelefone = new JLabel("Telefone");
		GridBagConstraints gbc_lblTelefone = new GridBagConstraints();
		gbc_lblTelefone.anchor = GridBagConstraints.WEST;
		gbc_lblTelefone.insets = new Insets(0, 0, 5, 5);
		gbc_lblTelefone.gridx = 3;
		gbc_lblTelefone.gridy = 2;
		layeredPane.add(lblTelefone, gbc_lblTelefone);
		
		JLabel lblSituao = new JLabel("Situa��o");
		GridBagConstraints gbc_lblSituao = new GridBagConstraints();
		gbc_lblSituao.anchor = GridBagConstraints.WEST;
		gbc_lblSituao.insets = new Insets(0, 0, 5, 0);
		gbc_lblSituao.gridx = 4;
		gbc_lblSituao.gridy = 2;
		layeredPane.add(lblSituao, gbc_lblSituao);
		
		txtCpf = new JTextField();
		GridBagConstraints gbc_txtCpf = new GridBagConstraints();
		gbc_txtCpf.insets = new Insets(0, 0, 5, 5);
		gbc_txtCpf.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtCpf.gridx = 0;
		gbc_txtCpf.gridy = 3;
		layeredPane.add(txtCpf, gbc_txtCpf);
		txtCpf.setColumns(10);
		
		
		String[] vetorSexo = {"Masculino","Feminino"};
		JComboBox comboBoxSexo = new JComboBox(vetorSexo);
		comboBoxSexo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				JComboBox sexo = (JComboBox)arg0.getSource();
				String conteudo = (String)sexo.getSelectedItem();
				
			}
		});
		
		
		txtRg = new JTextField();
		GridBagConstraints gbc_txtRg = new GridBagConstraints();
		gbc_txtRg.anchor = GridBagConstraints.NORTH;
		gbc_txtRg.insets = new Insets(0, 0, 5, 5);
		gbc_txtRg.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtRg.gridx = 1;
		gbc_txtRg.gridy = 3;
		layeredPane.add(txtRg, gbc_txtRg);
		txtRg.setColumns(10);
		GridBagConstraints gbc_comboBox = new GridBagConstraints();
		gbc_comboBox.insets = new Insets(0, 0, 5, 5);
		gbc_comboBox.fill = GridBagConstraints.HORIZONTAL;
		gbc_comboBox.gridx = 2;
		gbc_comboBox.gridy = 3;
		layeredPane.add(comboBoxSexo, gbc_comboBox);
		
		txtTelefone = new JTextField();
		GridBagConstraints gbc_txtTelefone = new GridBagConstraints();
		gbc_txtTelefone.insets = new Insets(0, 0, 5, 5);
		gbc_txtTelefone.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtTelefone.gridx = 3;
		gbc_txtTelefone.gridy = 3;
		layeredPane.add(txtTelefone, gbc_txtTelefone);
		txtTelefone.setColumns(10);
		
		/*txtSituacao = new JTextField();
		GridBagConstraints gbc_txtSituacao = new GridBagConstraints();
		gbc_txtSituacao.insets = new Insets(0, 0, 5, 0);
		gbc_txtSituacao.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtSituacao.gridx = 4;
		gbc_txtSituacao.gridy = 3;
		layeredPane.add(txtSituacao, gbc_txtSituacao);
		txtSituacao.setColumns(10);*/
		
		String[] vetorSituacao = {"Adimplente","Inadimplente"};
		JComboBox comboBoxSituacao = new JComboBox(vetorSituacao);
		comboBoxSituacao.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				JComboBox situacao = (JComboBox)arg0.getSource();
				String conteudo = (String)situacao.getSelectedItem();
				
			}
		});
		
		GridBagConstraints gbc_comboBoxSituacao = new GridBagConstraints();
		gbc_comboBoxSituacao.insets = new Insets(0, 0, 5, 0);
		gbc_comboBoxSituacao.fill = GridBagConstraints.HORIZONTAL;
		gbc_comboBoxSituacao.gridx = 4;
		gbc_comboBoxSituacao.gridy = 3;
		layeredPane.add(comboBoxSituacao, gbc_comboBoxSituacao);
		
		JLabel lblCidade = new JLabel("Cidade");
		GridBagConstraints gbc_lblCidade = new GridBagConstraints();
		gbc_lblCidade.anchor = GridBagConstraints.WEST;
		gbc_lblCidade.insets = new Insets(0, 0, 5, 5);
		gbc_lblCidade.gridx = 0;
		gbc_lblCidade.gridy = 4;
		layeredPane.add(lblCidade, gbc_lblCidade);
		
		JLabel lblUf = new JLabel("UF");
		GridBagConstraints gbc_lblUf = new GridBagConstraints();
		gbc_lblUf.anchor = GridBagConstraints.WEST;
		gbc_lblUf.insets = new Insets(0, 0, 5, 0);
		gbc_lblUf.gridx = 4;
		gbc_lblUf.gridy = 4;
		layeredPane.add(lblUf, gbc_lblUf);
		
		txtCidade = new JTextField();
		GridBagConstraints gbc_txtCidade = new GridBagConstraints();
		gbc_txtCidade.gridwidth = 4;
		gbc_txtCidade.insets = new Insets(0, 0, 5, 5);
		gbc_txtCidade.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtCidade.gridx = 0;
		gbc_txtCidade.gridy = 5;
		layeredPane.add(txtCidade, gbc_txtCidade);
		txtCidade.setColumns(10);
		
		txtUF = new JTextField();
		GridBagConstraints gbc_txtUF = new GridBagConstraints();
		gbc_txtUF.insets = new Insets(0, 0, 5, 0);
		gbc_txtUF.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtUF.gridx = 4;
		gbc_txtUF.gridy = 5;
		layeredPane.add(txtUF, gbc_txtUF);
		txtUF.setColumns(10);
		
		JLabel lblEmail = new JLabel("E-mail");
		GridBagConstraints gbc_lblEmail = new GridBagConstraints();
		gbc_lblEmail.anchor = GridBagConstraints.WEST;
		gbc_lblEmail.insets = new Insets(0, 0, 5, 5);
		gbc_lblEmail.gridx = 0;
		gbc_lblEmail.gridy = 6;
		layeredPane.add(lblEmail, gbc_lblEmail);
		
		JLabel lblDataDoAniversrio = new JLabel("Data do Anivers\u00E1rio (Dia/M\u00EAs/Ano)");
		GridBagConstraints gbc_lblDataDoAniversrio = new GridBagConstraints();
		gbc_lblDataDoAniversrio.anchor = GridBagConstraints.WEST;
		gbc_lblDataDoAniversrio.gridwidth = 3;
		gbc_lblDataDoAniversrio.insets = new Insets(0, 0, 5, 0);
		gbc_lblDataDoAniversrio.gridx = 2;
		gbc_lblDataDoAniversrio.gridy = 6;
		layeredPane.add(lblDataDoAniversrio, gbc_lblDataDoAniversrio);
		
		txtEmail = new JTextField();
		GridBagConstraints gbc_txtEmail = new GridBagConstraints();
		gbc_txtEmail.gridwidth = 2;
		gbc_txtEmail.insets = new Insets(0, 0, 5, 5);
		gbc_txtEmail.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtEmail.gridx = 0;
		gbc_txtEmail.gridy = 7;
		layeredPane.add(txtEmail, gbc_txtEmail);
		txtEmail.setColumns(10);
		
		JDateChooser dateChooser = new JDateChooser();
		GridBagConstraints gbc_dateChooser = new GridBagConstraints();
		gbc_dateChooser.insets = new Insets(0, 0, 5, 5);
		gbc_dateChooser.fill = GridBagConstraints.HORIZONTAL;
		gbc_dateChooser.gridx = 2;
		gbc_dateChooser.gridy = 7;
		layeredPane.add(dateChooser, gbc_dateChooser);
		
		JLabel lblEndereo = new JLabel("Endere�o:");
		GridBagConstraints gbc_lblEndereo = new GridBagConstraints();
		gbc_lblEndereo.anchor = GridBagConstraints.WEST;
		gbc_lblEndereo.insets = new Insets(0, 0, 5, 5);
		gbc_lblEndereo.gridx = 0;
		gbc_lblEndereo.gridy = 8;
		layeredPane.add(lblEndereo, gbc_lblEndereo);
		
		JLabel lblLogradouro = new JLabel("Logradouro");
		GridBagConstraints gbc_lblLogradouro = new GridBagConstraints();
		gbc_lblLogradouro.anchor = GridBagConstraints.WEST;
		gbc_lblLogradouro.insets = new Insets(0, 0, 5, 5);
		gbc_lblLogradouro.gridx = 0;
		gbc_lblLogradouro.gridy = 9;
		layeredPane.add(lblLogradouro, gbc_lblLogradouro);
		
		JLabel lblNmero = new JLabel("N�mero");
		GridBagConstraints gbc_lblNmero = new GridBagConstraints();
		gbc_lblNmero.anchor = GridBagConstraints.WEST;
		gbc_lblNmero.insets = new Insets(0, 0, 5, 5);
		gbc_lblNmero.gridx = 1;
		gbc_lblNmero.gridy = 9;
		layeredPane.add(lblNmero, gbc_lblNmero);
		
		JLabel lblComplemento = new JLabel("Complemento");
		GridBagConstraints gbc_lblComplemento = new GridBagConstraints();
		gbc_lblComplemento.anchor = GridBagConstraints.WEST;
		gbc_lblComplemento.insets = new Insets(0, 0, 5, 5);
		gbc_lblComplemento.gridx = 2;
		gbc_lblComplemento.gridy = 9;
		layeredPane.add(lblComplemento, gbc_lblComplemento);
		
		JLabel lblBairro = new JLabel("Bairro");
		GridBagConstraints gbc_lblBairro = new GridBagConstraints();
		gbc_lblBairro.anchor = GridBagConstraints.WEST;
		gbc_lblBairro.insets = new Insets(0, 0, 5, 5);
		gbc_lblBairro.gridx = 3;
		gbc_lblBairro.gridy = 9;
		layeredPane.add(lblBairro, gbc_lblBairro);
		
		JLabel lblCep = new JLabel("Cep");
		GridBagConstraints gbc_lblCep = new GridBagConstraints();
		gbc_lblCep.anchor = GridBagConstraints.WEST;
		gbc_lblCep.insets = new Insets(0, 0, 5, 0);
		gbc_lblCep.gridx = 4;
		gbc_lblCep.gridy = 9;
		layeredPane.add(lblCep, gbc_lblCep);
		
		txtLogradouro = new JTextField();
		GridBagConstraints gbc_txtLogradouro = new GridBagConstraints();
		gbc_txtLogradouro.insets = new Insets(0, 0, 0, 5);
		gbc_txtLogradouro.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtLogradouro.gridx = 0;
		gbc_txtLogradouro.gridy = 10;
		layeredPane.add(txtLogradouro, gbc_txtLogradouro);
		txtLogradouro.setColumns(10);
		
		txtNumero = new JTextField();
		GridBagConstraints gbc_txtNumero = new GridBagConstraints();
		gbc_txtNumero.insets = new Insets(0, 0, 0, 5);
		gbc_txtNumero.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtNumero.gridx = 1;
		gbc_txtNumero.gridy = 10;
		layeredPane.add(txtNumero, gbc_txtNumero);
		txtNumero.setColumns(10);
		
		txtComplemento = new JTextField();
		GridBagConstraints gbc_txtComplemento = new GridBagConstraints();
		gbc_txtComplemento.insets = new Insets(0, 0, 0, 5);
		gbc_txtComplemento.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtComplemento.gridx = 2;
		gbc_txtComplemento.gridy = 10;
		layeredPane.add(txtComplemento, gbc_txtComplemento);
		txtComplemento.setColumns(10);
		
		txtBairro = new JTextField();
		GridBagConstraints gbc_txtBairro = new GridBagConstraints();
		gbc_txtBairro.insets = new Insets(0, 0, 0, 5);
		gbc_txtBairro.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtBairro.gridx = 3;
		gbc_txtBairro.gridy = 10;
		layeredPane.add(txtBairro, gbc_txtBairro);
		txtBairro.setColumns(10);
		
		txtCep = new JTextField();
		GridBagConstraints gbc_txtCep = new GridBagConstraints();
		gbc_txtCep.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtCep.gridx = 4;
		gbc_txtCep.gridy = 10;
		layeredPane.add(txtCep, gbc_txtCep);
		txtCep.setColumns(10);
		
		JPanel panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.fill = GridBagConstraints.BOTH;
		gbc_panel.gridx = 0;
		gbc_panel.gridy = 1;
		contentPane.add(panel, gbc_panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gbl_panel.rowHeights = new int[]{0, 0, 0, 0, 0};
		gbl_panel.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		JButton btnSalvar = new JButton("Salvar (F2)");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(txtNomeDoCliente.getText().equals(null) 
						&& txtTelefone.getText().equals(null) 
						&& txtCpf.getText().equals(null)
						&& txtRg.getText().equals(null)
						&& txtTelefone.getText().equals(null) 
						&& txtCep.getText().equals(null) 
						&& txtLogradouro.getText().equals(null) 
						&& txtNumero.getText().equals(null) 
						&& txtComplemento.getText().equals(null)
						&& txtBairro.getText().equals(null) 
						&& txtCidade.getText().equals(null)) {
					JOptionPane.showMessageDialog(contentPane.getParent(), "Preencha todos os campos");
				} else {
					
					Endereco endereco = EnderecoDAO.cadastrarEndereco(txtLogradouro.getText(), txtNumero.getText(), txtComplemento.getText(), txtBairro.getText(), txtCidade.getText(), txtUF.getText(), txtCep.getText());
					
					ClienteDAO.cadastrarCliente(txtNomeDoCliente.getText(), txtTelefone.getText(), txtEmail.getText(), 
							comboBoxSexo.getSelectedItem().toString(), txtCpf.getText(), txtRg.getText(), comboBoxSituacao.getSelectedItem().toString(), dateChooser.getDate(), endereco);
					
					JOptionPane.showMessageDialog(contentPane.getParent(), "Cadastro realizado com sucesso.");
				}
			}
		});
		btnSalvar.setIcon(new ImageIcon(CadastroCliente.class.getResource("/imagens/iconSalvar.png")));
		GridBagConstraints gbc_btnSalvar = new GridBagConstraints();
		gbc_btnSalvar.anchor = GridBagConstraints.WEST;
		gbc_btnSalvar.insets = new Insets(0, 0, 5, 5);
		gbc_btnSalvar.gridx = 0;
		gbc_btnSalvar.gridy = 0;
		panel.add(btnSalvar, gbc_btnSalvar);
		
		JButton btnFechar = new JButton("Fechar (ESC)");
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//JOptionPane.showConfirmDialog(null, "Tem certeza de que quer fechar a janela e perder todo o Conte�do?");
				int resposta = JOptionPane.showConfirmDialog(null, "Deseja fechar a janela e perder o conteudo digitado?",
			    		"Janela de confirma��o", JOptionPane.YES_NO_OPTION);
			    
			    switch(resposta){
			    case JOptionPane.YES_OPTION:
			    	dispose();
			    	break;
			    case JOptionPane.NO_OPTION:
					
					
					break;
					default:
						break;
			    }
			    
				
			}
		});
		btnFechar.setIcon(new ImageIcon(CadastroCliente.class.getResource("/imagens/fechar32.png")));
		GridBagConstraints gbc_btnFechar = new GridBagConstraints();
		gbc_btnFechar.anchor = GridBagConstraints.EAST;
		gbc_btnFechar.insets = new Insets(0, 0, 5, 0);
		gbc_btnFechar.gridx = 6;
		gbc_btnFechar.gridy = 0;
		panel.add(btnFechar, gbc_btnFechar);
	}
}
